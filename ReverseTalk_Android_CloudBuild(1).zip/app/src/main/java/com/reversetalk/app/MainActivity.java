package com.reversetalk.app;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Process;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.TypedValue;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int REQUEST_MIC = 41;
    private static final int SAMPLE_RATE = 44100;
    private AudioRecord recorder;
    private Thread recordingThread;
    private volatile boolean isRecording = false;
    private final ByteArrayOutputStream recordedBytes = new ByteArrayOutputStream();
    private short[] recordedSamples = new short[0];
    private TextView status;
    private Button recordButton, stopButton, playButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
        updateButtons(false, false);
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(28), dp(24), dp(28));
        root.setBackgroundColor(Color.rgb(12, 10, 24));

        TextView title = new TextView(this);
        title.setText("Reverse Talk");
        title.setTextColor(Color.WHITE);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("سجّل صوتك واسمعه بالعكس");
        subtitle.setTextColor(Color.rgb(190, 180, 255));
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = matchWrap();
        subLp.topMargin = dp(12);
        subLp.bottomMargin = dp(34);
        root.addView(subtitle, subLp);

        status = new TextView(this);
        status.setText("جاهز للتسجيل");
        status.setTextColor(Color.WHITE);
        status.setTextSize(17);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = matchWrap();
        statusLp.bottomMargin = dp(28);
        root.addView(status, statusLp);

        recordButton = makeButton("🎙  ابدأ التسجيل");
        stopButton = makeButton("⏹  إيقاف التسجيل");
        playButton = makeButton("↶  شغّل الصوت بالعكس");
        root.addView(recordButton, buttonLp());
        root.addView(stopButton, buttonLp());
        root.addView(playButton, buttonLp());

        TextView hint = new TextView(this);
        hint.setText("اضغط تسجيل، اهدر، ثم أوقف التسجيل وشغّل الصوت بالعكس.");
        hint.setTextColor(Color.LTGRAY);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp = matchWrap();
        hintLp.topMargin = dp(30);
        root.addView(hint, hintLp);

        recordButton.setOnClickListener(v -> beginRecording());
        stopButton.setOnClickListener(v -> endRecording());
        playButton.setOnClickListener(v -> playReversed());
        setContentView(root);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams buttonLp() {
        LinearLayout.LayoutParams lp = matchWrap();
        lp.bottomMargin = dp(12);
        lp.height = dp(58);
        return lp;
    }

    private int dp(int value) {
        return (int)(value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void updateButtons(boolean recording, boolean hasAudio) {
        recordButton.setEnabled(!recording);
        stopButton.setEnabled(recording);
        playButton.setEnabled(!recording && hasAudio);
    }

    private void beginRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQUEST_MIC);
            return;
        }
        int min = AudioRecord.getMinBufferSize(SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) {
            status.setText("تعذّر تهيئة الميكروفون");
            return;
        }
        int bufferSize = Math.max(min, 4096);
        try {
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize);
            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                status.setText("الميكروفون غير جاهز");
                recorder.release();
                recorder = null;
                return;
            }
            recordedBytes.reset();
            recordedSamples = new short[0];
            recorder.startRecording();
            isRecording = true;
            updateButtons(true, false);
            status.setText("🔴 راه نسجّل... اهدر الآن");
            recordingThread = new Thread(() -> {
                Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);
                byte[] buffer = new byte[bufferSize];
                while (isRecording) {
                    int count = recorder.read(buffer, 0, buffer.length);
                    if (count > 0) {
                        synchronized (recordedBytes) {
                            recordedBytes.write(buffer, 0, count);
                        }
                    }
                }
            }, "AudioRecorder");
            recordingThread.start();
        } catch (Exception e) {
            isRecording = false;
            status.setText("وقع خطأ أثناء التسجيل");
            updateButtons(false, false);
        }
    }

    private void endRecording() {
        if (!isRecording) return;
        isRecording = false;
        try {
            if (recorder != null) {
                recorder.stop();
                recorder.release();
                recorder = null;
            }
            if (recordingThread != null) {
                recordingThread.join(1000);
                recordingThread = null;
            }
            byte[] bytes;
            synchronized (recordedBytes) { bytes = recordedBytes.toByteArray(); }
            int sampleCount = bytes.length / 2;
            recordedSamples = new short[sampleCount];
            for (int i = 0; i < sampleCount; i++) {
                int lo = bytes[i * 2] & 0xff;
                int hi = bytes[i * 2 + 1];
                recordedSamples[i] = (short)((hi << 8) | lo);
            }
            status.setText(sampleCount > 0 ? "تم التسجيل! اضغط تشغيل بالعكس" : "ما تسجّل حتى صوت");
            updateButtons(false, sampleCount > 0);
        } catch (Exception e) {
            status.setText("تعذّر إيقاف التسجيل بشكل صحيح");
            updateButtons(false, recordedSamples.length > 0);
        }
    }

    private void playReversed() {
        if (recordedSamples.length == 0) return;
        short[] reversed = new short[recordedSamples.length];
        for (int i = 0; i < recordedSamples.length; i++) {
            reversed[i] = recordedSamples[recordedSamples.length - 1 - i];
        }
        int min = AudioTrack.getMinBufferSize(SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack track = null;
        try {
            track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                .setAudioFormat(new AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build())
                .setBufferSizeInBytes(Math.max(min, reversed.length * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build();
            track.write(reversed, 0, reversed.length, AudioTrack.WRITE_BLOCKING);
            track.setNotificationMarkerPosition(reversed.length);
            AudioTrack finalTrack = track;
            track.setPlaybackPositionUpdateListener(new AudioTrack.OnPlaybackPositionUpdateListener() {
                @Override public void onMarkerReached(AudioTrack t) {
                    t.stop();
                    t.release();
                    runOnUiThread(() -> status.setText("كمل تشغيل الصوت بالعكس"));
                }
                @Override public void onPeriodicNotification(AudioTrack t) {}
            });
            status.setText("▶ راه يشغّل الصوت بالعكس...");
            track.play();
        } catch (Exception e) {
            if (track != null) track.release();
            status.setText("تعذّر تشغيل التسجيل");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQUEST_MIC && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            beginRecording();
        } else if (requestCode == REQUEST_MIC) {
            status.setText("لازم تسمح باستعمال الميكروفون");
        }
    }

    @Override protected void onDestroy() {
        if (isRecording) {
            isRecording = false;
            try {
                if (recorder != null) { recorder.stop(); recorder.release(); }
            } catch (Exception ignored) {}
        }
        super.onDestroy();
    }
}
